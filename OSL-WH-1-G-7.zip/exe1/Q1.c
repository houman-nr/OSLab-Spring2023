#include <stdio.h>

int main(){

	printf("Hi. It'sour first OS Lab exercise\n");

	printf("We are Fatemeh Ramazanian & Fatemeh Golpour\n");

	printf(" ******990122680089------990122680002******\n");

}