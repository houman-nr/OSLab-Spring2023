exe3=input("Hi.what's your name?")

print("Welcome "+exe3 +"\nNice to see you hear" )

